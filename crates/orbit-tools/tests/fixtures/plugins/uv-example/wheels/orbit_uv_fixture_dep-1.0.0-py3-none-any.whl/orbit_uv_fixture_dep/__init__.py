"""Third-party stand-in for the uv-example Orbit plugin fixture."""

__version__ = "1.0.0"
